package edu.ucalgary.oop;

public interface FormattedOutput {
    // just a method signature that returns a String
    // this is a method that must be implemented by any class that implements this interface
    public String getFormatted();
}

