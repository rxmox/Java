package edu.ucalgary.oop;

public enum Actions {
    FORWARD, LEFT, REVERSE, RIGHT, START, STOP;
}

