package edu.ucalgary.oop;

// No argument constructor
public class InvalidRewardsNumException extends Exception{
    public InvalidRewardsNumException(){
        super(""); // Call the super class constructor
    }
}

