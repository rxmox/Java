package edu.ucalgary.oop;

public class ArgFileNotFoundException extends Exception{
    public ArgFileNotFoundException(String message){
        super(message);
    }
    
}
