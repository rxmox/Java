package edu.ucalgary.oop;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class ToDoList implements IToDoList {
    private List<Task> tasks = new ArrayList<>();
    private Stack<Task[]> history = new Stack<>();

    private void saveCurrentState() {
        history.push(tasks.stream().map(Task::copy).toArray(Task[]::new));
    }

    @Override
    public void addTask(Task task) {
        saveCurrentState();
        tasks.add(task);
    }

    @Override
    public void completeTask(String id) {
        saveCurrentState();
        tasks.forEach(task -> {
            if (task.getId().equals(id)) {
                task.setCompleted(true);
            }
        });
    }

    @Override
    public void deleteTask(String id) {
        saveCurrentState();
        tasks.removeIf(task -> task.getId().equals(id));
    }

    @Override
    public void editTask(String id, String title, boolean isCompleted) {
        saveCurrentState();
        tasks.forEach(task -> {
            if (task.getId().equals(id)) {
                task.setTitle(title);
                task.setCompleted(isCompleted);
            }
        });
    }

    @Override
    public List<Task> listTasks() {
        return tasks;
    }

    @Override
    public void undo() {
        if (!history.isEmpty()) {
            Task[] previousState = history.pop();
            tasks.clear();
            for (Task task : previousState) {
                tasks.add(task.copy());
            }
        }
    }
}
