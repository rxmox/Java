package edu.ucalgary.oop;

import java.util.List;

public interface IToDoList {
    void addTask(Task t);

    void completeTask(String id);

    void deleteTask(String id);

    void editTask(String id, String title, boolean b);

    List<Task> listTasks();

    void undo();
}
