package edu.ucalgary.oop;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class ToDoList implements IToDoList{
    private List<Task> toDoList;
    private Stack<List<Task>> history;

    public ToDoList() {
        this.toDoList = new ArrayList<Task>();
        this.history = new Stack<List<Task>>();
    }

    @Override
    public void addTask(Task task) {
        history.push(new ArrayList<>(toDoList));
        toDoList.add(task);
    }

    @Override
    public boolean completeTask(String id) {
        boolean completed = false;

        for (Task element : toDoList) {
            if (element.getID().equals(id)) {
                element.setCompleted(true);
                completed = true;
                break;
            }
        }

        return completed;
    }

    @Override
    public void deleteTask(String id) {
        for (int i = 0; i < toDoList.size(); i++) {
            if (id.equals(toDoList.get(i).getID())) {
                history.push(new ArrayList<>(toDoList));
                toDoList.remove(i);
                break;
            }
        }
    }

    @Override
    public void editTask(String id, String title, boolean completed) {
        for (Task element : toDoList) {
            if (element.getID().equals(id)) {
                element.setTitle(title);
                element.setCompleted(completed);
                break;
            }
        }
    }

    @Override
    public List<Task> listTasks() {
        return toDoList;
    }

    public void undo() {
        toDoList = history.pop();
    }
    
}
