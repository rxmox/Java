package edu.ucalgary.oop;

import java.util.List;

public interface IToDoList {
    public void addTask(Task task);
    public boolean completeTask(String id);
    public void deleteTask(String id);
    public void editTask(String id, String title, boolean completed);
    public List<Task> listTasks();
}
