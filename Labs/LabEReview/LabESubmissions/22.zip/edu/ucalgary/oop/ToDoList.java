package edu.ucalgary.oop;

import java.util.*;

public class ToDoList implements IToDoList {
   
    private List<Task> tasks;
    private Stack<List<Task>> history;

    public ToDoList() {
        tasks = new ArrayList<>();
        history = new Stack<>();
    }

    @Override
    public void addTask(Task task) {
        saveCurrentState();
        tasks.add(task);
    }

    @Override
    public void completeTask(String id) {
        saveCurrentState();
        for (Task task : tasks) {
            if (task.getId().equals(id)) {
                task.setIsCompleted(true);
                break;
            }
        }
    }

    @Override
    public void deleteTask(String id) {
        saveCurrentState();
        tasks.removeIf(task -> task.getId().equals(id));
    }

    @Override
    public void editTask(String id, String title, boolean isCompleted) {
        saveCurrentState();
        for (Task task : tasks) {
            if (task.getId().equals(id)) {
                task.setTitle(title);
                task.setIsCompleted(isCompleted);
                break;
            }
        }
    }

    @Override
    public List<Task> listTasks() {
        return tasks;
    }
    
    @Override
    public void undo() {
        if (!history.isEmpty()) {
            tasks = history.pop();
        }
    }

    @Override
    public void saveCurrentState() {
        List<Task> currentState = new ArrayList<>();
        for (Task task : tasks) {
            currentState.add(new Task(task.getId(), task.getTitle()));
        }
        history.push(currentState);
    }
}
