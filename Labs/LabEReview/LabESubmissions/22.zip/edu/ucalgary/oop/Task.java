package edu.ucalgary.oop;

import java.util.*;

public class Task implements Cloneable{

    private String id;
    private String title;
    private boolean isCompleted;

    public Task(String id, String title){
        this.id = id;
        this.title = title;
        this.isCompleted = false;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Task task = (Task) obj;
        return Objects.equals(id, task.id) &&
               Objects.equals(title, task.title) &&
               isCompleted == task.isCompleted; 
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, title, isCompleted);
    }

    @Override
    public Object clone() throws CloneNotSupportedException{
        Task taskClone = (Task)super.clone();
        return taskClone;
    }

    public void setId(String id){
        this.id = id;
    }

    public void setTitle(String title){
        this.title = title;
    }

    public void setIsCompleted(boolean isCompleted){
        this.isCompleted = isCompleted;
    }
    
    public String getId(){
        return id;
    }

    public String getTitle(){
        return title;
    }

    public boolean isCompleted(){
        return isCompleted;
    }
}
