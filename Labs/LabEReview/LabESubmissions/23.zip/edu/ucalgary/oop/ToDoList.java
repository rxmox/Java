// ToDoList.java
package edu.ucalgary.oop;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class ToDoList implements IToDoList {
    private List<Task> tasks;
    private Stack<List<Task>> undoStack;

    public ToDoList() {
        this.tasks = new ArrayList<>();
        this.undoStack = new Stack<>();
    }

    @Override
    public void addTask(Task task) {
        // Make a deep copy of the current state before adding a task
        undoStack.push(new ArrayList<>(tasks));
        tasks.add(task);
    }

    @Override
    public void completeTask(String taskId) {
        // Find the task with the given ID and mark it as completed
        // Make a deep copy of the current state before completing a task
        undoStack.push(new ArrayList<>(tasks));
        for (Task task : tasks) {
            if (task.getId().equals(taskId)) {
                task.setCompleted(true);
                break;
            }
        }
    }

    @Override
    public void deleteTask(String taskId) {
        // Remove the task with the given ID
        // Make a deep copy of the current state before deleting a task
        undoStack.push(new ArrayList<>(tasks));
        tasks.removeIf(task -> task.getId().equals(taskId));
    }

    @Override
    public void editTask(String taskId, String newTitle, boolean newCompletionStatus) {
        // Find the task with the given ID and update its title and completion status
        // Make a deep copy of the current state before editing a task
        undoStack.push(new ArrayList<>(tasks));
        for (Task task : tasks) {
            if (task.getId().equals(taskId)) {
                task.setTitle(newTitle);
                task.setCompleted(newCompletionStatus);
                break;
            }
        }
    }

    @Override
    public List<Task> listTasks() {
        return new ArrayList<>(tasks);
    }

    @Override
    public void undo() {
        // Pop the previous state from the stack and set it as the current state
        if (!undoStack.isEmpty()) {
            tasks = undoStack.pop();
        }
    }
}
