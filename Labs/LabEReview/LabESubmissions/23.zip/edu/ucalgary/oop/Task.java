package edu.ucalgary.oop;

import java.util.Objects;

public class Task {

    private String id;
    private String title;
    private String description;
    private boolean isCompleted;

    public Task(String id, String title) {
        this.id = id;
        this.title = title;
        this.isCompleted = false; // By default, a new task is not completed
    }

    // Getter and Setter methods for description
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    // Getter method for id
    public String getId() {
        return id;
    }

    // Getter method for title
    public String getTitle() {
        return title;
    }

    public void setTitle(String newTitle){
        this.title  = newTitle;
    }

    // Getter method for isCompleted
    public boolean isCompleted() {
        return isCompleted;
    }

    // Method to mark the task as completed
    public void setCompleted(boolean completionStatus) {
        this.isCompleted = completionStatus;
    }

    // Method to copy the task (deep copy)
    public Task copy() {
        Task copiedTask = new Task(this.id, this.title);
        copiedTask.setDescription(this.description);
        copiedTask.isCompleted = this.isCompleted;
        return copiedTask;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Task task = (Task) obj;
        return Objects.equals(id, task.id) &&
               Objects.equals(title, task.title) &&
               isCompleted == task.isCompleted &&
               Objects.equals(description, task.description);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, title, description, isCompleted);
    }
}
