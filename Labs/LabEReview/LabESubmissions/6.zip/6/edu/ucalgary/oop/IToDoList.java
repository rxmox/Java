package edu.ucalgary.oop;


Import java.util.List;


public interface IToDoList {


    public void addTask(Task newTask){}


    public void completeTask(String id){}


   public void editTask(String id, String title, boolean completed){}


    public List<Task> listTasks(){}


    public void deleteTask(String id){}


    public void undoTask(){}
}
