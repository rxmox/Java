package edu.ucalgary.oop;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class ToDoList implements IToDoList {
    private List<Task> tasks = new ArrayList<>();
    private Stack<List<Task>> history = new Stack<>();

    private void saveCurrentState() {
        List<Task> copyOfCurrentState = new ArrayList<>();
        for (Task task : tasks) {
            copyOfCurrentState.add(task.copy());
        }
        history.push(copyOfCurrentState);
    }

    @Override
    public void addTask(Task task) {
        saveCurrentState();
        tasks.add(task);
    }

    @Override
    public void completeTask(String id) {
        saveCurrentState();
        for (Task task : tasks) {
            if (task.getId().equals(id)) {
                task.setCompleted(true);
                break;
            }
        }
    }

    @Override
    public void deleteTask(String id) {
        saveCurrentState();
        tasks.removeIf(task -> task.getId().equals(id));
    }

    @Override
    public void editTask(String id, String newTitle, String newDescription, boolean isCompleted) {
        saveCurrentState();
        for (Task task : tasks) {
            if (task.getId().equals(id)) {
                task.setTitle(newTitle);
                task.setDescription(newDescription);
                task.setCompleted(isCompleted);
                break;
            }
        }
    }

    @Override
    public List<Task> listTasks() {
        return tasks;
    }

    @Override
    public void undo() {
        if (!history.isEmpty()) {
            tasks = history.pop();
        }
    }
}
