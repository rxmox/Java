package edu.ucalgary.oop;


import java.util.Objects;


public class Task {
    private String id;
    private String title;
    private boolean isCompleted;


    public Task(String id, String title) {
        this.id = id;
        this.title = title;
        this.isCompleted = false; // Defaulting to not completed
    }


    public String getId() {
        return id;
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isCompleted() {
        return isCompleted;
    }


    public void setCompleted(boolean completed) {
        isCompleted = completed;
    }


    public Task copy() {
        return new Task(this.id, this.title); // Creating a new Task               	 object with the same id, title, and isCompleted values
    }







    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Task task = (Task) obj;
        return isCompleted == task.isCompleted &&
                Objects.equals(id, task.id) &&
                Objects.equals(title, task.title);
    }


    @Override
    public int hashCode() {
        return Objects.hash(id, title, isCompleted);
    }
}
