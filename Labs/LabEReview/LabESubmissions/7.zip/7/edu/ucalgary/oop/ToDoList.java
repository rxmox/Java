package edu.ucalgary.oop;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class ToDoList implements IToDoList {
    private List<Task> tasks = new ArrayList<>();
    private Stack<List<Task>> history = new Stack<>();

    private void saveState() {
        List<Task> currentState = new ArrayList<>();
        for (Task task : tasks) {
            currentState.add(task.copy());
        }
        history.push(currentState);
    }

    @Override
    public void addTask(Task task) {
        saveState();
        tasks.add(task);
    }

    @Override
    public void completeTask(String id) {
        saveState();
        for (Task task : tasks) {
            if (task.getId().equals(id)) {
                task.setCompleted(true);
                break;
            }
        }
    }

    @Override
    public void deleteTask(String id) {
        saveState();
        tasks.removeIf(task -> task.getId().equals(id));
    }

    @Override
    public void editTask(String id, String title, boolean isCompleted) {
        saveState();
        for (Task task : tasks) {
            if (task.getId().equals(id)) {
                task.setTitle(title);
                task.setCompleted(isCompleted);
                break;
            }
        }
    }

    @Override
    public List<Task> listTasks() {
        return tasks;
    }

    @Override
    public void undo() {
        if (!history.isEmpty()) {
            tasks = history.pop();
        }
    }
}
