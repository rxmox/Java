package edu.ucalgary.oop;

import java.util.*;

/**
 * IToDoList
 */
public interface IToDoList {

    void addTask(Task task);

    void completeTask(String taskNum);

    void deleteTask(String taskNum);

    ArrayList<Task> listTasks();

    void editTask(String taskNum,String newTaskTitle,boolean newTaskStatus);
    
}