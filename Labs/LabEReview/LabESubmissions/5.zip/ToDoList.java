package edu.ucalgary.oop;
import java.util.*;



public class ToDoList implements IToDoList {
    private List<Task> tasks;
    private Stack<List<Task>> history;

    public ToDoList() {
        tasks = new ArrayList<>();
        history = new Stack<>();
    }

    @Override
    public void addTask(Task task) {
        saveCurrentState();
        tasks.add(task);
    }

    @Override
    public void completeTask(String taskId) {
        saveCurrentState();
        tasks.stream()
             .filter(task -> task.getId().equals(taskId))
             .findFirst()
             .ifPresent(task -> task.setCompleted(true));
    }

    @Override
    public void deleteTask(String taskId) {
        saveCurrentState();
        tasks.removeIf(task -> task.getId().equals(taskId));
    }

    @Override
    public void editTask(String taskId, String newTitle, boolean isCompleted) {
        saveCurrentState();
        tasks.stream()
             .filter(task -> task.getId().equals(taskId))
             .findFirst()
             .ifPresent(task -> {
                 task.setTitle(newTitle);
                 task.setCompleted(isCompleted);
             });
    }

    @Override
    public ArrayList<Task> listTasks() {
        return new ArrayList<>(tasks); 
    }

    public void undo() {
        if (!history.isEmpty()) {
            tasks = history.pop();
        }
    }

    private void saveCurrentState() {
        List<Task> currentState = new ArrayList<>();
        for (Task task : tasks) {
            currentState.add(task.copy());
        }
        history.push(currentState);
    }
}
