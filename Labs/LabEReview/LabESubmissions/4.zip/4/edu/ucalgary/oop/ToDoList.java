package edu.ucalgary.oop;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class ToDoList {
    private List<Task> tasks;
    private Stack<List<Task>> history;

    public ToDoList() {
        tasks = new ArrayList<>();
        history = new Stack<>();
    }

    public void addTask(Task task) {
        history.push(new ArrayList<>(tasks)); // Save current state before adding
        tasks.add(task);
    }

    public void completeTask(String taskId) {
        history.push(new ArrayList<>(tasks)); // Save current state before completing
        for (Task task : tasks) {
            if (task.getId().equals(taskId)) {
                task.setCompleted(true);
                break;
            }
        }
    }

    public void deleteTask(String taskId) {
        history.push(new ArrayList<>(tasks)); // Save current state before deleting
        tasks.removeIf(task -> task.getId().equals(taskId));
    }

    public void editTask(String taskId, String newTitle, boolean newCompleted) {
        history.push(new ArrayList<>(tasks)); // Save current state before editing
        for (Task task : tasks) {
            if (task.getId().equals(taskId)) {
                task.setTitle(newTitle);
                task.setCompleted(newCompleted);
                break;
            }
        }
    }

    public List<Task> listTasks() {
        return new ArrayList<>(tasks);
    }

    public void undo() {
        if (!history.isEmpty()) {
            tasks = history.pop(); // Restore previous state
        }
    }
}

