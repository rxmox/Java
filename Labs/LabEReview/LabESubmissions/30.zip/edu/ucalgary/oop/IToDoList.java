package edu.ucalgary.oop;

import java.util.List;

public interface IToDoList {
    void addTask(Task task);
    void deleteTask(String id);
    void completeTask(String id);
    void editTask(String id, String title, boolean isCompleted);
    List<Task> listTasks();
    void undo();
}
