package edu.ucalgary.oop;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class ToDoList implements IToDoList {
    private List<Task> tasks;
    private Stack<List<Task>> historyStack;

    public ToDoList() {
        tasks = new ArrayList<>();
        historyStack = new Stack<>();
    }

    @Override
    public void addTask(Task task) {
        saveState();
        tasks.add(task);
    }

    @Override
    public void completeTask(String taskId) {
        Task task = findTaskById(taskId);
        if (task != null) {
            saveState();
            task.setCompleted(true);
            
        }
    }

    @Override
    public void deleteTask(String taskId) {
        Task task = findTaskById(taskId);
        if (task != null) {
            saveState();
            tasks.remove(task);
        }
    }

    @Override
    public void editTask(String taskId, String newTitle, boolean newIsCompleted) {
        Task task = findTaskById(taskId);
        if (task != null) {
            saveState();
            task.setTitle(newTitle);
            task.setCompleted(newIsCompleted);
        }
    }

    @Override
    public List<Task> listTasks() {
        return new ArrayList<>(tasks); 
    }

    @Override
    public void undo() {
        if (!historyStack.isEmpty()) {
            tasks = new ArrayList<>(historyStack.pop());

        }
    }

    private Task findTaskById(String taskId) {
        for (Task task : tasks) {
            if (task.getId().equals(taskId)) {
                return task;
            }
        }
        return null;
    }

    private void saveState() {
        historyStack.push(new ArrayList<>(tasks)); 
    }
}

