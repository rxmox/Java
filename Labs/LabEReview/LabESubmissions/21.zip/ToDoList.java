package edu.ucalgary.oop;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;

public class ToDoList implements IToDoList {

    List<Task> taskList;
    
    Stack<List<Task>> undoStack;

    //Constructor
    public ToDoList() {
        
        taskList = new ArrayList<Task>();
        undoStack = new Stack<List<Task>>();
    }
    
    //Add task
    public void addTask(Task task) {
    	
    	pushStateToUndo();
        taskList.add(task);
        
    }

    //Return list of tasks
    public List<Task> listTasks () {

    	
        return taskList;
    }

    //Complete a task
    public void completeTask(String id) {

    	pushStateToUndo();
        Task task = findTask(id);
        task.setCompleted(true);
    }

    //Delete a task
    public void deleteTask(String id) {

    	pushStateToUndo();
        Task task = findTask(id);
        taskList.remove(task);
    }

    //Edit a task
    public void editTask(String id, String title, boolean isCompleted) {
        
    	pushStateToUndo();
        Task task = findTask(id);
        task.setTitle(title);
        task.setCompleted(isCompleted);
    }
    
    //Undo a change
    public void undo() {
    	
    	taskList = undoStack.pop();
    }
    
    //Make a backup of the state to undo to
    private void pushStateToUndo() {
    	//Make a new copy of the state
    	List<Task> copyOfLists = new ArrayList<Task>();
    	
    	//Iterate through the current state
    	Iterator<Task> iterator = taskList.iterator();

        while (iterator.hasNext()) {
            Task task = iterator.next();
            //Add a copy of all tasks to the current undo state
            copyOfLists.add(task.copy());
        }
        
        //Push the new copy
        undoStack.push(copyOfLists);
    }
    
    //Find a task given an ID
    private Task findTask(String id) {
    	//Iterate through all tasks
        Iterator<Task> iterator = taskList.iterator();

        while (iterator.hasNext()) {
            Task task = iterator.next();
            //If the task matches the ID return that task
            if (task.getId().equals(id)) {
                return task;
            }
        }

        return null;
    }
}