package edu.ucalgary.oop;

import java.util.List;

interface IToDoList
{
    public void addTask(Task expectedTask);

    public List<Task> listTasks();

    public void completeTask(String number);

    public void deleteTask(String number);

    public void editTask(String number, String newTitle, boolean b);


}
