package edu.ucalgary.oop;

import java.util.Objects;

public class Task {

    String id;
    String title;
    boolean isCompleted;

    // Constructor with 2 arguments.
    public Task(String number, String taskName)
    {
        this.id = number;
        this.title = taskName;
    }

    // Check if task is completed
    public boolean isCompleted()
    {
        return isCompleted;
    }

    // Return the task title
    public String getTitle()
    {
        return title;
    }

    // Setter for the task title
    // Return the task title
    public void setTitle(String title)
    {
        this.title = title;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Task task = (Task) obj;
        return Objects.equals(id, task.id) &&
               Objects.equals(title, task.title) &&
               isCompleted == task.isCompleted; 
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, title, isCompleted);
    }

}
